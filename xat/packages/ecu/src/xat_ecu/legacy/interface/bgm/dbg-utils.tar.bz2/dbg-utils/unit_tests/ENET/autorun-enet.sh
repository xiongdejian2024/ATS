#! /bin/bash

source /unit_tests/test-utils.sh

print_name

#
# Exit status is 0 for PASS, nonzero for FAIL
#
STATUS=0

run_enet_setup()
{
	rm -f /tmp/detect-all-eth
	ifconfig |grep eth0.5 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: eth0.5 dev not find" >/tmp/detect-all-eth
		STATUS=1
	else
		echo "eth0.5 dev found" >/tmp/detect-all-eth
	fi
	
	ifconfig |grep eth0.9 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: eth0.9 dev not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "eth0.9 dev found" >>/tmp/detect-all-eth
	fi

	ifconfig |grep eth0.10 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: eth0.10 dev not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "eth0.10 dev found" >>/tmp/detect-all-eth
	fi

	ifconfig |grep eth0.11 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: eth0.11 dev not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "eth0.11 dev found" >>/tmp/detect-all-eth
	fi

	ifconfig |grep eth0.32 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: eth0.32 dev not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "eth0.32 dev found" >>/tmp/detect-all-eth
	fi

	cat /etc/resolv.conf | grep 'nameserver 172.16.5.31' 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: nameserver 172.16.5.31 not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "nameserver 172.16.5.31 found" >>/tmp/detect-all-eth
	fi

	cat /etc/resolv.conf | grep 'nameserver 172.16.32.31' 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: nameserver 172.16.32.31 not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "nameserver 172.16.32.31 found" >>/tmp/detect-all-eth
	fi

	cat /etc/resolv.conf | grep 'nameserver 172.16.11.13' 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: nameserver 172.16.11.13 not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "nameserver 172.16.11.13 found" >>/tmp/detect-all-eth
	fi

	arping -f 172.16.5.2 | grep "Received 1 response" 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: The network communication between MPU and MCU is not ok" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "The network communication between MPU and MCU is ok" >>/tmp/detect-all-eth
	fi

	ping 169.254.21.21 -c 4 | grep '64 bytes from 169.254.21.21' 2>&1 1>/dev/null
	if [ $? -ne 0 ] ;then
		echo "ERROR: ping 169.254.21.21 not find" >>/tmp/detect-all-eth
		STATUS=1
	else
		echo "ping 169.254.21.21 found" >>/tmp/detect-all-eth
	fi

	cat /tmp/detect-all-eth
	rm -f /tmp/detect-all-eth
}

run_enet_setup

print_status
exit $STATUS
