#!/bin/bash
sleep 18

file="/tmp/jiduer/mmap_file"
size=$((320 * 1024 * 1024))  # 320M
echo "===>>start swap mem <<===" >/dev/kmsg
dd if=/dev/zero of="$file" bs=$size count=1

rm "$file"

exit 0