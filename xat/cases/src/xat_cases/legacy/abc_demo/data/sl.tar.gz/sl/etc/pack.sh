#!/bin/sh

if [ "A" != "$1" -a "B" != "$1" ]; then
	echo "parm error"
	exit 0
fi

snapshot_str="mem-snapshot$1.img"

echo $snapshot_str

if [ "A" == "$1" ]; then
        dd if=/dev/mmcblk0p9 of=/update/$snapshot_str bs=1M && sync
else
        dd if=/dev/mmcblk0p10 of=/update/$snapshot_str bs=1M && sync
fi

cd /update

tar -cjf $snapshot_str.bz2 $snapshot_str

exit 0
