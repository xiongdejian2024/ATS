#!/bin/bash
if [ -e /data/capture_tcpdump.sh ]; then
  /data/capture_tcpdump.sh &
fi

if [ -e /data/debug.sh ]; then
  counter_file="/data/debug_script_executed_count"

  if [[ ! -f $counter_file ]]; then
      echo "0" > $counter_file
  fi

  counter=$(cat $counter_file)
  if [[ $counter -ge 20 ]]; then
      rm /data/debug.sh
      exit 0
  fi

  counter=$((counter+1))
  echo "debug script executed count "$counter > /dev/kmsg
  echo $counter > $counter_file
fi
