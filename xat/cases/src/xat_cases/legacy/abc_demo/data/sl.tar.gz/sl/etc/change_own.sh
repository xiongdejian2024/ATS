#!/bin/bash

echo "---- begin chown " `date +%s%3N` " ----" >> /dev/kmsg

for ((i=1; i<=40; i++))
do
  result=$(eval "mount -n | grep update")
  if [ -z "$result" ]
  then
    if [ "$i" -eq 40 ];then
      echo "--- check /update timeout ---" > /dev/kmsg
    fi
    usleep 50000
  else
    echo "--- check /update success ---" > /dev/kmsg
    break
  fi
done

# 定义用户own和对应文件和目录的关系
declare -A file_owners=(
  [vehInfoServer]="/data/vehicleInfo.json"
  [fota]="/update/state.pb /update/state-backup.pb /update/version.json"
  [ua_server_app]="/update/update_agent_persist.json"
)

declare -A folder_owners=(
    [certificate_service]="/data/certificate /data/persistent/certificate_service"
    [em2]="/data/em2 /data/persistent/em2"
    [diagd_iautosar]="/data/diagd_iautosar /update/factory /data/persistent/diagd_iautosar"
    [remote_diag]="/data/remote_diag /data/persistent/remote_diag"
    [config_service]="/data/config_service /data/persistent/config_service"
    [config_master]="/data/config_master /data/persistent/config_master"
    [vehicle_setting_service]="/data/vehicle_setting_service /data/persistent/vehicle_setting_service"
    [vehicle_data_mining_engine]="/data/vehicle_data_mining_engine /data/persistent/vehicle_data_mining_engine"
    [security_alarm]="/data/security_alarm /data/persistent/security_alarm"
    [fod]="/data/fod /data/persistent/fod"
    [prop]="/data/prop_service /data/persistent/prop"
    [syncengine]="/data/sync /data/persistent/syncengine"
    [remote_log]="/data/remote_log /data/persistent/remote_log"
    [rke]="/data/rke /data/persistent/rke"
    [s2s_service]="/data/s2s_service /data/persistent/s2s_service"
    [SOAApp]="/data/SOAApp /data/persistent/SOAApp"
    [fota]="/data/fota /data/persistent/fota /update/fota /update/factory/decrypt /update/fota/decrypt"
    [remote_rescue]="/data/remote_rescue /data/persistent/remote_rescue"
    [sys_monitor]="/data/sys_monitor /data/persistent/sys_monitor"
    [ua_server_app]="/update/ua /update/installer /data/persistent/ua_server_app"
    [app_service_manager]="/data/app_service_manager /data/persistent/app_service_manager"
    [vehInfoServer]="/data/vehInfoServer /data/persistent/vehInfoServer"
    [calibration]="/data/calibration /data/persistent/calibration"
    [jetcrashd]="/data/jetcrashd /data/persistent/jetcrashd /log/jetcrash"
    [monitor_agent]="/data/monitor_agent /data/persistent/monitor_agent"
    [nids]="/log/nids"
    [log_master]="/data/log_master /data/persistent/log_master"
)


chmod -R 775 /log/*

if [ -e "/data/config_service" ];then
   chmod -R 775 /data/config_service/*;
fi

# 遍历所有文件和目录，并设置对应的own
for owner in "${!file_owners[@]}"; do
  for file in ${file_owners[$owner]}; do
    if [ -e $file ];then
        chown $owner:0 $file
    else
        touch $file;chown $owner:0 $file;chmod 664 $file
    fi
  done
done

for owner in "${!folder_owners[@]}"; do
  for folder in ${folder_owners[$owner]}; do
    if [ ! -e $folder ];then
      mkdir -p $folder
    fi
    chown -R $owner:0 $folder
    if [[ "$folder" == /update* ]];then
      chmod 775 $folder
    elif [[ "$folder" == /data/persistent* ]];then
      chmod 744 $folder
    elif [[ "$folder" == /data/certificate ]]; then
      continue
    else
      chmod 755 $folder
    fi
  done
done

chmod -R 775 /data/certificate
chmod 775 /data/certificate/vbf_pk.pem

echo "---- finish chown " `date +%s%3N` " ----" >> /dev/kmsg
