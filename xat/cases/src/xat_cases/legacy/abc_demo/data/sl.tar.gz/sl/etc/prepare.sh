#!/bin/sh

resumed=$(cat /sys/power/sys_resumed)

if [ "$resumed" -ne 0 ]; then
    echo "The resumed value is not 0. Exiting..."
    exit 1
fi

snapshot_file="/data/snapshot"

if [ ! -f "$snapshot_file" ]; then
  echo "Creating file $snapshot_file"
  touch "$snapshot_file"
fi

result=$(/app/bin/swdl -nr 8)

if [ "$result" != "$1" ]; then
	/app/bin/swdl -nw 8 $1
fi


exit 0