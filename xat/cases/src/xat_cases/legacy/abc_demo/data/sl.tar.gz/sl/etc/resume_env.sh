#!/bin/sh
echo "===>>start from resume_env <<===" >/dev/kmsg


function check_mount()
{
    partition=$1
     if [ "$partition"X == "update"X ]; then
        mmclblk=mmcblk0p7
    elif [ "$partition"X == "data"X ]; then
        mmclblk=mmcblk0p6
    elif [ "$partition"X == "log"X ]; then
        mmclblk=mmcblk0p8
    elif [ "$partition"X == "mnt"X ]; then
        mmclblk=mmcblk0p11
    else
        echo "unknown partition";
        exit -1;
    fi
    echo "check mount for $partition ........................."

    for ((i=1; i<=20; i++))
    do
        result=$(eval "mount -n | grep $partition")
        if [ -z "$result" ]
        then
            if [ "$i" -eq 20 ];then
                echo "--- check $partition timeout ---" > /dev/kmsg
                result=$(eval "mount -t ext4 /dev/$mmclblk /$partition -o defaults")
                if [[ $result -eq 0 ]];then
                    echo "--- mount /$partition success  ---" > /dev/kmsg
                else
                    usleep 50000
                    echo "--- mount /$partition failed retry 1 ---" > /dev/kmsg
                    result=$(eval "mount -t ext4 /dev/$mmclblk /$partition -o defaults")
                    if [[ $result -eq 0 ]];then
                        echo "--- mount /$partition success  ---" > /dev/kmsg
                    else
                        usleep 50000
                        echo "--- mount /$partition failed retry 2 ---" > /dev/kmsg
                        result=$(eval "mount -t ext4 /dev/$mmclblk /$partition -o defaults")
                        if [[ $result -eq 0 ]];then
                            echo "--- mount /$partition success  ---" > /dev/kmsg
                        else
                            echo "--- mount /$partition failed ---" > /dev/kmsg
                        fi
                    fi
                fi
            fi
            usleep 25000
        else
            echo "--- check  $partition success ---" > /dev/kmsg
            break
        fi
    done
}

partitions=("update" "data" "log")
for value in ${partitions[@]}
do
    check_mount $value &
done

coredump_dir="/log/coredump"

if [ ! -d "$coredump_dir" ]; then
    mkdir -p "$coredump_dir"
fi
etc_dir="/data/etc"
if [ ! -d "$etc_dir" ]; then
    mkdir -p "$etc_dir"
fi
flag="/update/resume_permisson_adjust_flag"
if [ -f "$flag" ] ; then
    if [ "$(cat "$flag")" == "2" ];then
        echo "Flag is already set to 2. Exiting." > /dev/kmsg
        echo "===>>endof resume_env <<===" > /dev/kmsg
        exit 0
    elif [ "$(cat "$flag")" == "1" ];then
        echo "2" > $flag
        echo "Flag is already set to 1. Exiting." > /dev/kmsg
        echo "===>>endof resume_env <<===" > /dev/kmsg
        exit 0
    fi
fi
if [ -z "$(mount | grep "/log")" ]; then
    echo "ERROR: not mounted log" > /dev/kmsg
    mkfs.ext4 -F -E nodiscard /dev/mmcblk0p8
    mount -t ext4 /dev/mmcblk0p8 /log -o defaults
fi

# 定义用户own和对应文件和目录的关系
declare -A file_owners=(
    [vehInfoServer]="/data/vehicleInfo.json"
    [fota]="/update/state.pb /update/state-backup.pb /update/version.json"
    [remote_rescue]="/update/rescue_state.json"
    [ua_server_app]="/update/update_agent_persist.json"
)

declare -A folder_owners=(
    [certificate_service]="/data/certificate /data/persistent/certificate_service"
    [em2]="/data/em2 /data/persistent/em2"
    [diagd_iautosar]="/data/diagd_iautosar /update/factory /data/persistent/diagd_iautosar"
    [remote_diag]="/data/remote_diag /data/persistent/remote_diag"
    [config_service]="/data/config_service /data/persistent/config_service"
    [config_master]="/data/config_master /data/persistent/config_master"
    [vehicle_setting_service]="/data/vehicle_setting_service /data/persistent/vehicle_setting_service"
    [vehicle_data_mining_engine]="/data/vehicle_data_mining_engine /data/persistent/vehicle_data_mining_engine"
    [security_alarm]="/data/security_alarm /data/persistent/security_alarm"
    [fod]="/data/fod /data/persistent/fod"
    [prop]="/data/prop_service /data/persistent/prop"
    [syncengine]="/data/sync /data/persistent/syncengine"
    [remote_log]="/data/remote_log /data/persistent/remote_log"
    [rke]="/data/rke /data/persistent/rke"
    [s2s_service]="/data/s2s_service /data/persistent/s2s_service"
    [SOAApp]="/data/SOAApp /data/persistent/SOAApp"
    [fota]="/data/fota /data/persistent/fota /update/fota /update/factory/decrypt /update/fota/decrypt"
    [remote_rescue]="/data/remote_rescue /data/persistent/remote_rescue"
    [sys_monitor]="/data/sys_monitor /data/persistent/sys_monitor"
    [ua_server_app]="/update/ua /update/installer /data/persistent/ua_server_app"
    [app_service_manager]="/data/app_service_manager /data/persistent/app_service_manager"
    [vehInfoServer]="/data/vehInfoServer /data/persistent/vehInfoServer"
    [calibration]="/data/calibration /data/persistent/calibration"
    [jetcrashd]="/data/jetcrashd /data/persistent/jetcrashd /log/jetcrash"
    [monitor_agent]="/data/monitor_agent /data/persistent/monitor_agent"
    [nids]="/log/nids"
    [log_master]="/data/log_master /data/persistent/log_master"
)

chmod -R 775 /log/*

if [ -e "/data/config_service" ];then
    chmod -R 755 /data/config_service/*;
fi

echo "--- chown file ---" > /dev/kmsg
# 遍历所有文件和目录，并设置对应的own
for owner in "${!file_owners[@]}"; do
    for file in ${file_owners[$owner]}; do
        if [ -e $file ];then
            chown $owner:0 $file
        else
            touch $file;chown $owner:0 $file;chmod 664 $file
        fi
    done
done

echo "--- chown folder ---" > /dev/kmsg
for owner in "${!folder_owners[@]}"; do
    for folder in ${folder_owners[$owner]}; do
        if [ ! -e $folder ];then
            mkdir -p $folder
        fi
        chown -R $owner:0 $folder

        if [[ "$folder" == /update* ]];then
            chmod 775 $folder
        elif [[ "$folder" == /data/persistent* ]];then
            chmod 744 $folder
        else
            chmod 755 $folder
        fi
    done
done

echo "--- chmod certificate ---" > /dev/kmsg
certificate_dir="/data/certificate"
certificate_file="/data/certificate/vbf_pk.pem"

if [ -d "$certificate_dir" ]; then
    chmod 775 "$certificate_dir"
else
    echo "Directory does not exist: $certificate_dir"  > /dev/kmsg
fi

if [ -f "$certificate_file" ]; then
    chmod 775 "$certificate_file"
else
    echo "File does not exist: $certificate_file"  > /dev/kmsg
fi


chmod 755 /data
chmod 775 /log /update /dev/kmsg
chmod 664 /sys/class/gpio/export /sys/class/gpio/unexport /dev/mmcblk0* /dev/spidev*

echo "1" > $flag

echo "===>>endof resume_env <<===" >/dev/kmsg
