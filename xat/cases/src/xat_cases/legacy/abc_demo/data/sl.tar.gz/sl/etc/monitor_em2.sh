#!/bin/bash
process_name="em2"
while true
do
  if ! pgrep -x $process_name > /dev/null
  then
    #echo "$process_name is not running, restarting it..."
    /app/bin/$process_name &
  fi
  sleep 5s
done