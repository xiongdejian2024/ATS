#!/bin/bash

dmesg -c
pkill jetlogd

sleep 1
if fuser -m /data/ >/dev/null 2>&1; then
	count=$(fuser -m /data/ | wc -w)

	if [ "$count" -gt 0 ]; then
		echo "fuser /data/ count > 0 exit !"
		exit 1
	fi
fi

if fuser -m /update/ >/dev/null 2>&1; then
	count=$(fuser -m /update/ | wc -w)

	if [ "$count" -gt 0 ]; then
		echo "fuser /update/ count > 0 exit !"
		exit 1
	fi
fi

if fuser -m /log/ >/dev/null 2>&1; then
    count=$(fuser -m /log/ | wc -w)
    echo "fuser /log count is $count "
    if [ "$count" -gt 1 ]; then
        echo "count != 1"
        exit 0
    else
        pid=$(fuser -m /log/ | awk '{print $NF}')
        process_name=$(ps -p "$pid" -o comm= 2>/dev/null)
        if [ "$process_name" = "syslogd" ]; then
            echo "3"
        else
            exit 1
        fi
    fi
fi

sys_to_s2d_then_resume.sh

exit 0

