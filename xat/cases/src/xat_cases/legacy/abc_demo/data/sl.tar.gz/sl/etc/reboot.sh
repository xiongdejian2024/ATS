#!/bin/bash

#1) 切换到root 用户: sudo -s 
#2）执行脚本：./reboot.sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/app/lib
export BOOTES_HOME_DIR=/app/etc

/app/bin/powerClient -R