#!/bin/sh
cd /data
shopt -s extglob
rm -rf !(certificate|storage|s2sdb|vehicleInfo.json|seco_hsm)
rm -rf /update/*